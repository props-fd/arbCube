"""Dimension-agnostic n^d cube engine.

Follows SPEC.md section 3 and reference/sim_prototype.py exactly: stickers sorted by position q,
perm[i] = destination slot of the sticker at slot i, fixed frame (odd n: the centre layer never
turns; even n: the layer holding the (-(n-1), ...) reference cubie never turns).
"""
from __future__ import annotations

import itertools

import numpy as np

PUZZLES = {"222": (2, 3), "333": (3, 3), "444": (4, 3), "2222": (2, 4), "3333": (3, 4)}


def rotations(d: int, a: int) -> list[np.ndarray]:
    """Every d x d signed permutation matrix with det +1 that fixes axis a, except I."""
    others = [i for i in range(d) if i != a]
    out = []
    for p in itertools.permutations(others):
        for signs in itertools.product([1, -1], repeat=d - 1):
            R = np.zeros((d, d), int)
            R[a, a] = 1
            for src, dst, s in zip(others, p, signs):
                R[dst, src] = s
            if round(np.linalg.det(R)) == 1 and not (R == np.eye(d, dtype=int)).all():
                out.append(R)
    return out


def is_quarter(R: np.ndarray) -> bool:
    """A single 90-degree turn in one coordinate plane."""
    eye = np.eye(len(R), dtype=int)
    return (np.diag(R) == 1).sum() == len(R) - 2 and not (R @ R == eye).all()


class Cube:
    def __init__(self, name: str, metric: str = "qtm"):
        self.name, self.metric = name, metric
        n, d = self.n, self.d = PUZZLES[name]
        V = range(-(n - 1), n, 2)
        stick = []
        for c in itertools.product(V, repeat=d):
            for j in range(d):
                if abs(c[j]) == n - 1:
                    s = 1 if c[j] > 0 else -1
                    q = list(c)
                    q[j] = s * n
                    stick.append((tuple(q), c, j, s))
        stick.sort()
        self.pos = np.array([t[0] for t in stick])                     # [N, d]
        self.axis = np.array([t[2] for t in stick])
        self.sign = np.array([t[3] for t in stick])
        self.solved = 2 * self.axis + (self.sign > 0)                   # colour = home facet id
        self.slots = np.array(sorted({t[1] for t in stick}))           # [S, d] visible cubies
        slot_id = {tuple(c): i for i, c in enumerate(self.slots)}
        self.slot_of = np.array([slot_id[t[1]] for t in stick])
        where = {t[0]: i for i, t in enumerate(stick)}
        cub = self.slots[self.slot_of]
        layers = [L for L in V if (L != 0 if n % 2 else L != -(n - 1))]

        self.moves, perms, sperms = [], [], []
        for a in range(d):
            for L in layers:
                for R in rotations(d, a):
                    if metric == "qtm" and not is_quarter(R):
                        continue
                    perm, sp = np.arange(len(stick)), np.arange(len(self.slots))
                    on, son = cub[:, a] == L, self.slots[:, a] == L
                    perm[on] = [where[tuple(R @ q)] for q in self.pos[on]]
                    sp[son] = [slot_id[tuple(R @ c)] for c in self.slots[son]]
                    order = next(k for k in (2, 3, 4) if (np.linalg.matrix_power(R, k) == np.eye(d)).all())
                    i, j = np.flatnonzero(np.diag(R) != 1)[:2] if is_quarter(R) else (-1, -1)
                    self.moves.append(dict(axis=a, layer=L, R=R, order=order, depth=abs(L) / (n - 1),
                                           outer=abs(L) == n - 1, plane=(int(i), int(j), int(R[j, i]) if i >= 0 else 0)))
                    perms.append(perm)
                    sperms.append(sp)
        self.perm, self.slot_perm = np.array(perms), np.array(sperms)  # [M, N], [M, S]
        self.gather = np.argsort(self.perm, axis=1)                    # new[k] = old[gather[k]]
        key = {(m["axis"], m["layer"], m["R"].tobytes()): k for k, m in enumerate(self.moves)}
        self.inv = np.array([key[(m["axis"], m["layer"], m["R"].T.copy().tobytes())] for m in self.moves])
        ax = np.array([m["axis"] for m in self.moves])
        ly = np.array([m["layer"] for m in self.moves])
        # canonical sequences: never undo the last move (qtm) or re-turn its layer (htm); same-axis layers ascend
        bad = (ax[:, None] == ax[None]) & (ly[None] < ly[:, None])
        bad |= ((ax[:, None] == ax[None]) & (ly[:, None] == ly[None])) if metric == "htm" else (self.inv[:, None] == np.arange(len(ax)))
        self.allowed = np.vstack([~bad, np.ones(len(ax), bool)])       # row M = "no previous move"
        self._hv = np.random.default_rng(0).integers(1, 2**63, len(stick), dtype=np.uint64)

    @property
    def M(self) -> int:
        return len(self.moves)

    def apply(self, states: np.ndarray, moves) -> np.ndarray:
        return np.take_along_axis(states, self.gather[moves], -1)

    def is_solved(self, states: np.ndarray) -> np.ndarray:
        return (states == self.solved).all(-1)

    def hash(self, states: np.ndarray) -> np.ndarray:
        return (states.astype(np.uint64) * self._hv).sum(-1)

    def walks(self, B: int, K: int, rng: np.random.Generator):
        """B canonical random walks of K moves from solved. Returns every prefix state [B, K, N] and moves [B, K]."""
        s = np.broadcast_to(self.solved, (B, len(self.solved))).copy()
        prev = np.full(B, self.M)
        states, moves = [], []
        for _ in range(K):
            m = np.argmax(rng.random((B, self.M)) * self.allowed[prev], 1)
            s = self.apply(s, m)
            prev = m
            states.append(s)
            moves.append(m)
        return np.stack(states, 1), np.stack(moves, 1)
