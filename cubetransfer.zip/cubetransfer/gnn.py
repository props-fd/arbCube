"""Puzzle-agnostic GNN heuristic (SPEC.md sections 5-6).

Nodes are visible cubie slots. Every feature is defined without reference to a specific puzzle
(no slot or move one-hots), so one set of weights runs on any n^d cube and any move set.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from cube import Cube


class Graph:
    """Piece-slot graph: static per-puzzle tensors, plus vectorised dynamic features from a state batch."""
    F_IN, N_STATIC = 9, 1

    def __init__(self, cube: Cube, device):
        n, d, self.name, self.cube, dev = cube.n, cube.d, cube.name, cube, device
        self.n, self.d = n, d
        C = torch.tensor(cube.slots, dtype=torch.float32, device=dev)
        S, N = len(C), len(cube.pos)
        self.C, self.S = C, S
        self.A = F.one_hot(torch.tensor(cube.slot_of, device=dev), S).float()   # sticker -> slot incidence
        self.k = self.A.sum(0)
        self.fa = torch.tensor(cube.axis, device=dev)
        self.fs = torch.tensor(cube.sign > 0, device=dev).long()
        self.solved = torch.tensor(cube.solved, device=dev)
        diff = (C[:, None] - C[None]).abs()
        adj = ((diff == 2).sum(-1) == 1) & ((diff == 0).sum(-1) == d - 1)
        self.A_static = (adj.float() / adj.sum(1, keepdim=True).clamp(min=1))[None]   # [relations, S, S]
        self.radix = n ** torch.arange(d, device=dev)
        self.table = torch.full((n**d,), -1, dtype=torch.long, device=dev)
        self.table[self._code(C)] = torch.arange(S, device=dev)
        fixed = torch.tensor((cube.slot_perm == range(S)).all(0), device=dev).float()
        self.static = torch.stack([self.k / d, self.k, fixed], -1)
        # moves
        self.G = torch.tensor(cube.gather, device=dev)
        self.P = torch.tensor(cube.perm, device=dev)
        pm, ps = [], []
        for m, mv in enumerate(cube.moves):
            s = (cube.slots[:, mv["axis"]] == mv["layer"]).nonzero()[0]
            pm += [m] * len(s)
            ps += list(s)
        self.pm = torch.tensor(pm, device=dev)
        self.ps = torch.tensor(ps, device=dev)
        self.pd = torch.tensor(cube.slot_perm, device=dev)[self.pm, self.ps]
        self.pool = torch.zeros(cube.M, len(pm), device=dev)          # mean over each move's affected slots
        self.pool[self.pm, torch.arange(len(pm), device=dev)] = 1 / torch.bincount(self.pm).float()[self.pm]
        self.move_feat = torch.tensor([[mv["order"] == 2, mv["order"] == 3, mv["order"] == 4, mv["depth"], mv["outer"]]
                                       for mv in cube.moves], dtype=torch.float32, device=dev)
        self.allowed = torch.tensor(cube.allowed, device=dev)
        self.inv = torch.tensor(cube.inv, device=dev)

    def _code(self, coords):
        return (((coords + self.n - 1) / 2).round().long() * self.radix).sum(-1)

    def _home(self, det, val, at):
        """Nearest home slot: colour-determined axes are fixed, the rest are clamped to the interior."""
        lo = -(self.n - 3)
        return torch.where(det, val, at.clamp(min(lo, -lo), max(lo, -lo)) if self.n > 2 else val)

    def features(self, s):
        n, d = self.n, self.d
        ca, cs = s // 2, s % 2                                            # each colour's home facet
        own = (ca == self.fa) & (cs == self.fs)
        same_axis = ca == self.fa
        st = torch.stack([own, same_axis & ~own, ~same_axis], -1).float()
        frac = torch.einsum("bnf,ns->bsf", st, self.A) / self.k[:, None]
        oh = F.one_hot(ca, d).float()
        det = torch.einsum("bnd,ns->bsd", oh, self.A) > 0
        val = torch.einsum("bnd,ns->bsd", oh * ((2 * cs - 1) * (n - 1))[..., None].float(), self.A)
        home = self._home(det, val, self.C.expand_as(val))
        norm = 2 * (n - 1) * d
        dist = (self.C - home).abs().sum(-1)
        x = torch.cat([self.static.expand(len(s), -1, -1), frac, (frac[..., :1] == 1).float(),
                       (dist / norm)[..., None], (self.C != home).float().mean(-1, keepdim=True)], -1)
        hidx = self.table[self._code(home)]
        # per (move, affected slot) deltas: how far the piece gets from home, and how many stickers land on their facet
        Cd = self.C[self.pd]
        ddist = ((Cd - self._home(det[:, self.ps], val[:, self.ps], Cd.expand(len(s), -1, -1))).abs().sum(-1)
                 - dist[:, self.ps]) / norm
        own_after = (s[:, None, :] == self.solved[self.P]).float()          # sticker i lands at P[m, i]
        down = torch.einsum("bmn,ns->bms", own_after, self.A)[:, self.pm, self.ps] - frac[:, self.ps, 0] * self.k[self.ps]
        return x, hidx, torch.stack([ddist, down / self.k[self.ps]], -1)


class RGCN(nn.Module):
    """Relation-typed message passing: self, each static relation, a dynamic home relation and its
    reverse. LayerNorm + residual. Weight layout is [self, static..., home, home_rev]."""

    def __init__(self, H, n_static=1):
        super().__init__()
        self.W = nn.Linear(H, (3 + n_static) * H)
        self.norm = nn.LayerNorm(H)

    def forward(self, h, A, hidx):
        hs, *st, hh, hr = self.W(h).chunk(3 + len(A), -1)
        idx = hidx[..., None].expand_as(hr)
        rev = torch.zeros_like(hr).scatter_add_(1, idx, hr)
        cnt = torch.zeros_like(hr[..., 0]).scatter_add_(1, hidx, torch.ones_like(hr[..., 0]))
        m = hs + sum(a @ x for a, x in zip(A, st)) + hh.gather(1, idx) + rev / cnt.clamp(min=1)[..., None]
        return self.norm(h + F.relu(m))


def mlp(i, h, o):
    return nn.Sequential(nn.Linear(i, h), nn.ReLU(), nn.Linear(h, o))


class GNN(nn.Module):
    def __init__(self, H=128, L=4, F_in=9, n_static=1):
        super().__init__()
        self.inp = nn.Linear(F_in, H)
        self.layers = nn.ModuleList(RGCN(H, n_static) for _ in range(L))
        self.u = mlp(H, H, 1)                      # node_sum value readout (size-extensive)
        # psi([h_i || h_pi(i) || deltas]) split into per-node projections; mean commutes with the output layer
        self.psi_src, self.psi_dst, self.psi_pair = nn.Linear(H, H), nn.Linear(H, H, bias=False), nn.Linear(2, H, bias=False)
        self.psi_out = nn.Linear(H, H)
        self.pol = mlp(H + 5, H, 1)
        self.calib = nn.ParameterDict()            # per-puzzle (a_P, b_P); zero-shot uses (1, 0)

    def add_puzzle(self, name):
        if name not in self.calib:
            self.calib[name] = nn.Parameter(torch.tensor([1.0, 0.0]))

    def forward(self, g: Graph, s):
        x, hidx, pair = g.features(s)
        h = self.inp(x)
        for layer in self.layers:
            h = layer(h, g.A_static, hidx)
        u = self.u(h).squeeze(-1)
        a, b = self.calib[g.name] if g.name in self.calib else (1.0, 0.0)
        v = a * F.softplus(u.sum(-1)) + b
        e = F.relu(self.psi_src(h).index_select(1, g.ps) + self.psi_dst(h).index_select(1, g.pd) + self.psi_pair(pair))
        e = self.psi_out(g.pool @ e)
        logits = self.pol(torch.cat([e, g.move_feat.expand(len(s), -1, -1)], -1)).squeeze(-1)
        return v, logits, u


class StickerGraph:
    """Sticker-facet graph (SPEC 5.2): one node per sticker plus 2d facet nodes. Static relations
    adj / same_piece / on / on_rev; the dynamic relation 'belongs' links each sticker to its colour's
    home facet. Unlike the piece-slot graph this keeps which facet every sticker wants, so it can tell
    a clockwise corner twist from a counter-clockwise one."""
    F_IN, N_STATIC = 9, 4

    def __init__(self, cube: Cube, device):
        n, d, self.name, self.cube, dev = cube.n, cube.d, cube.name, cube, device
        N, nf = len(cube.pos), 2 * d
        self.N, self.S = N, N + nf
        self.C = torch.tensor(cube.pos, dtype=torch.float32, device=dev)
        self.solved = torch.tensor(cube.solved, device=dev)
        facet = self.solved                                               # sticker slot's own facet id
        q = self.C
        diff = (q[:, None] - q[None]).abs()
        adj = ((diff == 2).sum(-1) == 1) & ((diff == 0).sum(-1) == d - 1)
        slot = torch.tensor(cube.slot_of, device=dev)
        same = (slot[:, None] == slot[None]) & ~torch.eye(N, dtype=torch.bool, device=dev)
        on = F.one_hot(facet, nf).bool()
        z = torch.zeros
        def full(top_left=None, top_right=None, bottom_left=None):
            A = z(self.S, self.S, dtype=torch.bool, device=dev)
            if top_left is not None: A[:N, :N] = top_left
            if top_right is not None: A[:N, N:] = top_right
            if bottom_left is not None: A[N:, :N] = bottom_left
            return A.float() / A.sum(1, keepdim=True).clamp(min=1)
        self.A_static = torch.stack([full(adj), full(same), full(top_right=on), full(bottom_left=on.T)])
        k = torch.bincount(slot).float()[slot]
        fixed = torch.tensor((cube.slot_perm == range(len(cube.slots))).all(0), device=dev)[slot].float()
        self.static = torch.cat([torch.stack([torch.ones(N, device=dev), z(N, device=dev), k / d, k, fixed], -1),
                                 torch.cat([z(nf, 1, device=dev), torch.ones(nf, 1, device=dev), z(nf, 3, device=dev)], -1)])
        self.fa, self.fs = torch.tensor(cube.axis, device=dev), torch.tensor(cube.sign > 0, device=dev).long()
        self.slot, self.k = slot, k
        self.facet_self = torch.arange(N, N + nf, device=dev)
        # moves: one (move, sticker) pair per sticker in the turning layer
        self.G = torch.tensor(cube.gather, device=dev)
        perm = torch.tensor(cube.perm, device=dev)
        cub = cube.slots[cube.slot_of]
        pm, ps = [], []
        for m, mv in enumerate(cube.moves):
            st = (cub[:, mv["axis"]] == mv["layer"]).nonzero()[0]
            pm += [m] * len(st)
            ps += list(st)
        self.pm, self.ps = torch.tensor(pm, device=dev), torch.tensor(ps, device=dev)
        self.pd = perm[self.pm, self.ps]
        self.pool = z(cube.M, len(pm), device=dev)
        self.pool[self.pm, torch.arange(len(pm), device=dev)] = 1 / torch.bincount(self.pm).float()[self.pm]
        self.move_feat = torch.tensor([[mv["order"] == 2, mv["order"] == 3, mv["order"] == 4, mv["depth"], mv["outer"]]
                                       for mv in cube.moves], dtype=torch.float32, device=dev)
        self.allowed = torch.tensor(cube.allowed, device=dev)
        self.inv = torch.tensor(cube.inv, device=dev)

    def features(self, s):
        B, N = s.shape
        ca, cs = s // 2, s % 2
        own = (ca == self.fa) & (cs == self.fs)
        same_axis = ca == self.fa
        piece_solved = torch.zeros(B, len(self.cube.slots), device=s.device).index_add_(1, self.slot, own.float())
        piece_solved = (piece_solved[:, self.slot] == self.k).float()
        dyn = torch.stack([own, same_axis & ~own, ~same_axis], -1).float()
        dyn = torch.cat([dyn, piece_solved[..., None]], -1)
        x = self.static.expand(B, -1, -1).clone()
        x = torch.cat([x, torch.cat([dyn, torch.zeros(B, self.S - N, 4, device=s.device)], 1)], -1)
        hidx = torch.cat([N + s, self.facet_self.expand(B, -1)], 1)       # 'belongs': sticker -> colour's facet
        own_p = own[:, self.ps].float()
        after = (s[:, self.ps] == self.solved[self.pd]).float()
        return x, hidx, torch.stack([after - own_p, own_p], -1)


GRAPHS = {"slot": Graph, "sticker": StickerGraph}


class MLP(nn.Module):
    """DeepCubeA-style ResMLP over one-hot sticker colours (SPEC 6.2). It has a fixed input size and a
    fixed-size policy over one puzzle's move set, so it cannot transfer; it is the specialised baseline."""

    def __init__(self, cube: Cube, H=256, blocks=2):
        super().__init__()
        self.C = 2 * cube.d
        self.inp = nn.Sequential(nn.Linear(len(cube.pos) * self.C, H), nn.ReLU())
        self.blocks = nn.ModuleList(nn.Sequential(nn.Linear(H, H), nn.LayerNorm(H), nn.ReLU(), nn.Linear(H, H)) for _ in range(blocks))
        self.v, self.pi = nn.Linear(H, 1), nn.Linear(H, cube.M)

    @classmethod
    def matched(cls, cube: Cube, target: int, blocks=2):
        """Width chosen so the parameter count is as close as possible to `target` (the GNN's)."""
        count = lambda H: sum(p.numel() for p in cls(cube, H, blocks).parameters())
        return cls(cube, min(range(32, 1025, 8), key=lambda H: abs(count(H) - target)), blocks)

    def add_puzzle(self, name):
        pass

    def forward(self, g, s):
        x = self.inp(F.one_hot(s, self.C).flatten(1).float())
        for b in self.blocks:
            x = F.relu(x + b(x))
        return self.v(x).squeeze(-1), self.pi(x), None
