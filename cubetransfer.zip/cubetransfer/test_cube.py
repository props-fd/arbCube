import numpy as np
import pytest

from cube import PUZZLES, Cube

SPEC = {  # stickers, visible slots, htm, qtm, piece-type counts (SPEC.md 3.4)
    "222": (24, 8, 9, 6, {3: 8}), "333": (54, 26, 18, 12, {1: 6, 2: 12, 3: 8}),
    "444": (96, 56, 27, 18, {1: 24, 2: 24, 3: 8}), "2222": (64, 16, 92, 24, {4: 16}),
    "3333": (216, 80, 184, 48, {1: 8, 2: 24, 3: 32, 4: 16}),
}


@pytest.mark.parametrize("name", PUZZLES)
def test_counts(name):
    N, S, htm, qtm, types = SPEC[name]
    c = Cube(name, "qtm")
    assert len(c.pos) == N and len(c.slots) == S and c.M == qtm and Cube(name, "htm").M == htm
    assert dict(zip(*np.unique(np.bincount(c.slot_of), return_counts=True))) == types


@pytest.mark.parametrize("name", PUZZLES)
@pytest.mark.parametrize("metric", ["qtm", "htm"])
def test_perms(name, metric):
    c = Cube(name, metric)
    for k, m in enumerate(c.moves):
        p = c.perm[k]
        assert sorted(p) == list(range(len(p)))                       # bijection
        assert (p[c.perm[c.inv[k]]] == np.arange(len(p))).all() or (c.perm[c.inv[k]][p] == np.arange(len(p))).all()
        q, order = np.arange(len(p)), 0
        while True:
            q, order = p[q], order + 1
            if (q == np.arange(len(p))).all():
                break
        assert order == m["order"]
    s = c.slot_perm
    fixed = (s == np.arange(s.shape[1])).all(0)
    if c.n % 2:   # centres never move
        assert fixed[(np.abs(c.slots) == c.n - 1).sum(1) == 1].all()
    else:         # reference cubie never moves
        assert fixed[(c.slots == -(c.n - 1)).all(1)].all()


def test_333_face_turn_and_3333_twist():
    c = Cube("333")
    k = next(i for i, m in enumerate(c.moves) if m["outer"])
    moved = c.slot_perm[k] != np.arange(26)
    assert np.bincount(np.bincount(c.slot_of)[moved])[2:].tolist() == [4, 4]
    h = Cube("3333")
    k = next(i for i, m in enumerate(h.moves) if m["outer"])
    moved = h.slot_perm[k] != np.arange(80)
    assert np.bincount(np.bincount(h.slot_of)[moved], minlength=5)[2:].tolist() == [4, 12, 8]


@pytest.mark.parametrize("name", PUZZLES)
def test_scramble_then_inverse_is_identity(name):
    c = Cube(name)
    rng = np.random.default_rng(1)
    s, m = c.walks(8, 30, rng)
    x = s[:, -1]
    for t in reversed(range(30)):
        x = c.apply(x, c.inv[m[:, t]])
    assert c.is_solved(x).all()
