"""Solve rate by scramble depth over training, for scratch and the 1M-state 333 model (zero-shot + fine-tune)."""
import sys, json, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, ".")
import run
from cube import Cube
from gnn import GNN, Graph
dev, T = "mps", sys.argv[1]
c = Cube(T); g = Graph(c, dev)
rng = np.random.default_rng(5); s, mv = c.walks(240, 20, rng)
depth = np.repeat(np.arange(2, 22, 2), 24)[:240]; st = s[np.arange(240), depth - 1]
def by_depth(m):
    ok = np.array([p is not None for p in run.beam_search(m, g, st, 32, int(depth.max()) + 4)])
    return {int(k): round(float(ok[depth == k].mean()), 2) for k in np.unique(depth)}
for regime in ["finetune", "scratch"]:
    torch.manual_seed(0); m = GNN().to(dev)
    if regime == "finetune":
        m.add_puzzle("333"); m.load_state_dict(torch.load(sys.argv[2]))
    m.add_puzzle(T); opt = torch.optim.AdamW(m.parameters(), 1e-3); seen = 0
    print(regime, 0, by_depth(m), flush=True)
    for step in range(5):
        for x, dp, tg in run.batches(c, 26, np.random.default_rng(step), np.array([], np.uint64), 200_000):
            x, dp, tg = (torch.tensor(a, device=dev) for a in (x, dp, tg))
            v, lg, _ = m(g, x); loss = F.huber_loss(v, dp.float()) + F.cross_entropy(lg, tg)
            opt.zero_grad(); loss.backward(); opt.step()
        print(regime, (step + 1) * 200_000, by_depth(m), flush=True)
