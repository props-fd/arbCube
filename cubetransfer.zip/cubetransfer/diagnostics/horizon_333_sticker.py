import sys, time, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, ".")
import run
from cube import Cube
from gnn import GNN, StickerGraph as Graph
dev = "mps"; c = Cube("333"); g = Graph(c, dev); torch.manual_seed(0)
m = GNN(F_in=9, n_static=4).to(dev); m.add_puzzle("333"); opt = torch.optim.AdamW(m.parameters(), 1e-3)
suite = run.make_suite(c, 14); rng = np.random.default_rng(0)
t = time.time()
for s, dep, tgt in run.batches(c, 24, rng, c.hash(suite[0]), 1_000_000):
    s, dep, tgt = (torch.tensor(x, device=dev) for x in (s, dep, tgt))
    v, lg, _ = m(g, s); loss = F.huber_loss(v, dep.float()) + F.cross_entropy(lg, tgt)
    opt.zero_grad(); loss.backward(); opt.step()
print("train s", round(time.time() - t))
torch.save(m.state_dict(), "/tmp/claude-501/-Users-benmcaulay-Library-Application-Support-Claude-scratch-workspaces-213042e6-3b3f-4b4e-8c16-e0428c3be079-22f9d993-4553-4d91-9cb4-4d135fca40df-scratch-2026-11-10-bccfd5/5d1af1e3-9e64-43c6-8e83-29a5fcb6e35a/scratchpad/diag333_sticker.pt")
for W in [32, 128]:
    t = time.time(); sol = run.beam_search(m, g, suite[0], W, 18)
    ok = np.array([p is not None for p in sol])
    by = {k: round(ok[suite[1] == k].mean(), 2) for k in range(1, 15)}
    print(W, "solve", ok.mean(), "ms/solve", round(1000 * (time.time() - t) / 100), by)
