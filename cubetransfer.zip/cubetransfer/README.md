# cubetransfer

Does a GNN heuristic trained on one n^d cube transfer to another? This trains a puzzle-agnostic GNN on
the 3x3x3 until it solves, fine-tunes it on the 4x4x4 and the 3x3x3x3, and compares against the same
network trained from scratch on the same budget of training states.

| file | what it is |
|---|---|
| `cube.py` | n^d cube engine (any n, d = 3 or 4), same conventions as the team's `sim_prototype.py` |
| `gnn.py` | piece-slot and sticker-facet graph features, relation-typed GNN with value and move-set-agnostic policy heads, parameter-matched MLP baseline |
| `run.py` | training, batched beam search, the transfer experiment, JSON export for the viewer |
| `test_cube.py` | the SPEC section 3.4 count / bijection / fixed-frame checks |
| `web/index.html` | the viewer: animated solves (3D and projected 4D), learning curves, Findings and Code tabs |
| `out_slot/`, `out_sticker/` | results, logs and the cached 3x3x3 checkpoint for each graph |
| `diagnostics/` | one-off depth-horizon scripts and their logs |

## Run

```bash
uv venv --python 3.11 .venv && uv pip install --python .venv/bin/python -r requirements.txt
.venv/bin/python -m pytest -q test_cube.py
.venv/bin/python run.py --graph slot --out out_slot                       # 333 -> 444, 3333; seeds 0 1 2
.venv/bin/python run.py --graph slot --out out_slot --targets 444 --seeds 3 4 5   # adds seeds to the same results
.venv/bin/python run.py --graph sticker --out out_sticker --targets 444    # sticker-facet graph ablation
.venv/bin/python run.py --graph slot --out out_slot --ceiling --targets 444 --seeds 0 1 2   # fixed 3M-state ceiling test vs MLP
.venv/bin/python run.py --quick --seeds 0 --out /tmp/smoke                 # 1-minute smoke test
```

`<out>/gnn_333.pt` is cached per output folder; delete it to re-pretrain. Re-running a target with new seeds adds
them to `results.json`; re-running a seed replaces it. `diagnostics/` holds the one-off depth-horizon scripts and
their logs that the Findings tab quotes.

## View

```bash
cp out_slot/results.json web/results_slot.json && cp out_sticker/results.json web/results_sticker.json && cp out_slot/ceiling_444.json web/ && python3 -m http.server -d web 8765   # then open http://localhost:8765
```

The Code tab reads copies in `web/code/`; re-copy `*.py` and `README.md` there after editing them.

`web/` is a static folder (Three.js from cdnjs, everything else inline), so it deploys as-is to any static
host (GitHub Pages, Netlify, Vercel, or a claude.ai artifact).

## Protocol

- Metric: QTM (quarter turns; 12 / 18 / 48 moves for 333 / 444 / 3333). Fixed frame per SPEC 3.2.
- Data: every prefix of canonical random walks from solved (depth label, plus the inverse of the last move
  as the policy target). States in the frozen test suite are rejected from training.
- "Solved" = beam search (width 32, cumulative policy log-prob) solves >= 90% of 100 frozen scrambles with
  depth uniform in 1..K_eval, within K_eval + 4 moves. Every returned solution is replayed in the engine.
- Training stops at that threshold or at the budget. Budget is counted in training states seen.
- Fine-tune = start from the 3x3x3 checkpoint; scratch = fresh init with the same seed, data and optimiser.

## Deviations from SPEC.md (deliberate, to keep this a milestone-sized prototype)

- Pure PyTorch/numpy, no Streamlit; the viewer is a static page that only shows numbers read from
  `results.json`.
- Piece-slot graph with edges `[adj, home]` (the spec default), plus the spec 5.2 sticker-facet graph as an
  ablation (`--graph sticker`). The orientation cycle-type histogram is replaced by own/opposite/orthogonal
  facet fractions. Both graphs hit the same depth horizon on 3x3x3 (about 10 QTM), so the features are not
  the whole explanation.
- The policy's per-pair input adds two puzzle-agnostic deltas: the change in the piece's distance to home,
  and in its stickers on their own facet, if the move is applied.
- The MLP baseline (one-hot stickers, parameter-matched within 10%) runs only in the 4x4x4 ceiling test, at a
  budget matched in training states, not compute.
- No 222 BFS oracle, AVI, or external datasets; no sticker-facet runs on 3x3x3x3.
