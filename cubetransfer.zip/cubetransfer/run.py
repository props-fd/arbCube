"""Transfer experiment: pretrain a GNN on a source cube until it solves, then compare fine-tuning
against training from scratch on target cubes. Writes out/results.json for the web viewer.

    python run.py                         # 333 -> 444, 3333; 3 seeds
    python run.py --targets 444 --seeds 0 --quick
"""
from __future__ import annotations

import argparse
import copy
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from cube import Cube
from gnn import GNN, GRAPHS, MLP, Graph

# K_train: max scramble depth of training walks. K_eval: test-suite depths are uniform in 1..K_eval.
# "Solves" = beam search (width BEAM) solves >= THRESHOLD of the frozen suite within K_eval + 4 moves.
CFG = {
    "333": dict(K_train=24, K_eval=10, budget=8e6, eval_every=2.5e5),
    "444": dict(K_train=26, K_eval=9, budget=2e6, eval_every=1e5),
    "3333": dict(K_train=14, K_eval=8, budget=1.5e6, eval_every=1e5),
}
THRESHOLD, BEAM, SUITE, BATCH, LR = 0.9, 32, 100, 512, 1e-3
GRAPH = Graph


def device(name: str) -> str:
    if name != "auto":
        return name
    return "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"


def make_suite(cube: Cube, K: int, n: int = SUITE, seed: int = 12345):
    """Frozen test states: canonical scrambles with depth uniform in 1..K. Returns (states, depths, moves)."""
    rng = np.random.default_rng(seed)
    states, moves = cube.walks(n, K, rng)
    depth = rng.integers(1, K + 1, n)
    return states[np.arange(n), depth - 1], depth, [moves[i, : depth[i]].tolist() for i in range(n)]


def batches(cube: Cube, K: int, rng, banned: np.ndarray, total: int):
    """Self-supervised data: every prefix of canonical walks, shuffled. Label = depth, policy target = undo last move."""
    yielded = 0
    while yielded < total:
        s, m = cube.walks(4096 // K * 8, K, rng)
        s, depth, tgt = s.reshape(-1, s.shape[-1]), np.tile(np.arange(1, K + 1), len(s)), cube.inv[m.reshape(-1)]
        ok = ~np.isin(cube.hash(s), banned)                       # test-set hygiene
        perm = rng.permutation(np.flatnonzero(ok))
        for i in range(0, len(perm) - BATCH + 1, BATCH):
            j = perm[i : i + BATCH]
            yield s[j], depth[j], tgt[j]
            yielded += BATCH
            if yielded >= total:
                return


@torch.no_grad()
def beam_search(model, g: Graph, states: np.ndarray, W: int, max_depth: int):
    """Batched beam search scored by cumulative policy log-prob. Returns a move list (or None) per instance."""
    model.eval()
    dev = g.C.device
    chunk = max(128, 400_000 // len(g.pm))                           # bounds the (state, move, slot) activations
    I, N = states.shape
    beams = torch.tensor(states, device=dev)[:, None]
    score = torch.zeros(I, 1, device=dev)
    last = torch.full((I, 1), g.cube.M, device=dev)
    paths = torch.zeros(I, 1, 0, dtype=torch.long, device=dev)
    active, sol = torch.arange(I, device=dev), [None] * I
    for t in range(max_depth + 1):
        done = (beams == g.solved).all(-1)
        hit = done.any(1)
        for i in hit.nonzero().flatten().tolist():
            sol[active[i].item()] = paths[i, done[i].nonzero()[0, 0]].tolist()
        beams, score, last, paths, active = (x[~hit] for x in (beams, score, last, paths, active))
        if t == max_depth or len(active) == 0:
            break
        Ia, w = beams.shape[:2]
        flat = beams.reshape(-1, N)
        logp = torch.cat([F.log_softmax(model(g, c)[1], -1) for c in flat.split(chunk)]).view(Ia, w, -1)
        cand = (score[..., None] + logp.masked_fill(~g.allowed[last], -torch.inf)).view(Ia, -1)
        score, idx = cand.topk(min(W, cand.shape[1]), 1)
        pb, mv = idx // g.cube.M, idx % g.cube.M
        parent = beams.gather(1, pb[..., None].expand(-1, -1, N))
        beams = parent.gather(2, g.G[mv])
        paths = torch.cat([paths.gather(1, pb[..., None].expand(-1, -1, t)), mv[..., None]], 2)
        last = mv
    for i, p in enumerate(sol):                                      # always verify by replay in the engine
        if p is not None:
            s = states[i : i + 1]
            for m in p:
                s = g.cube.apply(s, [m])
            assert g.cube.is_solved(s).all(), "beam search returned an invalid solution"
    return sol


def evaluate(model, g: Graph, suite) -> dict:
    t = time.time()
    sol = beam_search(model, g, suite[0], BEAM, int(suite[1].max()) + 4)
    lens = [len(p) for p in sol if p is not None]
    ok = np.array([p is not None for p in sol])
    return dict(solve=len(lens) / len(sol), length=float(np.mean(lens)) if lens else None,
                ms_per_solve=1000 * (time.time() - t) / len(sol),
                by_depth={int(k): round(float(ok[suite[1] == k].mean()), 3) for k in np.unique(suite[1])})


def train(model: GNN, cube: Cube, seed: int, dev: str, label: str, K_eval=None, budget=None, n_suite=SUITE,
          stop=True, eval_every=None) -> list[dict]:
    """Train on `cube` until the suite solve rate hits THRESHOLD (if `stop`) or the budget runs out."""
    cfg, g = dict(CFG[cube.name]), GRAPH(cube, dev)
    cfg.update({k: v for k, v in dict(K_eval=K_eval, budget=budget, eval_every=eval_every).items() if v is not None})
    suite = make_suite(cube, cfg["K_eval"], n_suite)
    model.add_puzzle(cube.name)
    opt = torch.optim.AdamW(model.parameters(), LR)
    rng, seen, wall = np.random.default_rng(seed), 0, 0.0
    curve = [dict(states=0, wall=0.0, **evaluate(model, g, suite))]
    print(f"[{label}] {curve[-1]}", flush=True)
    while seen < cfg["budget"] and (curve[-1]["solve"] < THRESHOLD or not stop):
        model.train()
        t = time.time()
        for s, depth, tgt in batches(cube, cfg["K_train"], rng, cube.hash(suite[0]), int(cfg["eval_every"])):
            s, depth, tgt = (torch.tensor(x, device=dev) for x in (s, depth, tgt))
            v, logits, _ = model(g, s)
            loss = F.huber_loss(v, depth.float()) + F.cross_entropy(logits, tgt)
            opt.zero_grad()
            loss.backward()
            opt.step()
        seen += int(cfg["eval_every"])
        wall += time.time() - t
        curve.append(dict(states=seen, wall=round(wall, 1), loss=round(loss.item(), 4), **evaluate(model, g, suite)))
        print(f"[{label}] {curve[-1]}", flush=True)
    return curve


@torch.no_grad()
def demos(model, cube: Cube, dev: str, seed=777) -> list[dict]:
    """Fresh scrambles solved by `model`, with the value head's distance estimate along the solution."""
    K = CFG[cube.name]["K_eval"]
    depths = sorted({max(2, K // 4), K // 2, 3 * K // 4, K})
    g, rng, out = GRAPH(cube, dev), np.random.default_rng(seed), []
    s, m = cube.walks(len(depths), max(depths), rng)
    for i, k in enumerate(depths):
        start = s[i, k - 1 : k]
        t = time.time()
        sol = beam_search(model, g, start, BEAM, k + 4)[0]
        ms = 1000 * (time.time() - t)
        path = [start]
        for mv in sol or []:
            path.append(cube.apply(path[-1], [mv]))
        v = model(g, torch.tensor(np.concatenate(path), device=dev))[0]
        out.append(dict(depth=k, scramble=m[i, :k].tolist(), solution=sol, ms=round(ms),
                        value=[round(x, 2) for x in v.tolist()]))
    return out


def geometry(cube: Cube) -> dict:
    cub = cube.slots[cube.slot_of]
    return dict(n=cube.n, d=cube.d, pos=cube.pos.tolist(), cubie=cub.tolist(), color=cube.solved.tolist(),
                moves=[dict(axis=m["axis"], layer=m["layer"], plane=m["plane"], perm=cube.perm[k].tolist())
                       for k, m in enumerate(cube.moves)])


def ceiling(a, dev: str, out: Path):
    """Fixed budget, no early stop, deeper suite: does pretraining (or the shared GNN design) cap the final level?
    Regimes: GNN fine-tuned from the source checkpoint, GNN from scratch, parameter-matched MLP from scratch."""
    T, cube = a.targets[0], Cube(a.targets[0])
    src = GNN(F_in=GRAPH.F_IN, n_static=GRAPH.N_STATIC).to(dev)
    src.add_puzzle(a.source)
    src.load_state_dict(torch.load(out / f"gnn_{a.source}.pt"))
    params = sum(p.numel() for p in src.parameters())
    path = out / f"ceiling_{T}.json"
    C = json.loads(path.read_text()) if path.exists() else dict(runs={})
    C.update(target=T, source=a.source, graph=a.graph, budget=a.ceiling_budget, K_eval=a.ceiling_depth, suite=a.ceiling_suite,
             eval_every=2.5e5, beam=BEAM, gnn_params=params)
    for seed in a.seeds:
        torch.manual_seed(seed)
        models = {"finetune": copy.deepcopy(src), "scratch": GNN(F_in=GRAPH.F_IN, n_static=GRAPH.N_STATIC).to(dev),
                  "mlp": MLP.matched(cube, params).to(dev)}
        for regime, model in models.items():
            curve = train(model, cube, seed, dev, f"ceiling {regime} {T} seed {seed}", K_eval=a.ceiling_depth,
                          budget=a.ceiling_budget, n_suite=a.ceiling_suite, stop=False, eval_every=C["eval_every"])
            runs = [r for r in C["runs"].get(regime, []) if r["seed"] != seed]
            C["runs"][regime] = sorted(runs + [dict(seed=seed, params=sum(p.numel() for p in model.parameters()), curve=curve)],
                                       key=lambda r: r["seed"])
            path.write_text(json.dumps(C))


def first_hit(curve):
    return next((p["states"] for p in curve if p["solve"] >= THRESHOLD), None)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="333")
    ap.add_argument("--targets", nargs="+", default=["444", "3333"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--device", default="auto")
    ap.add_argument("--out", default="out")
    ap.add_argument("--graph", default="slot", choices=["slot", "sticker"], help="piece-slot or sticker-facet graph")
    ap.add_argument("--ceiling", action="store_true", help="fixed-budget ceiling test on the first target (GNN ft / GNN scratch / MLP)")
    ap.add_argument("--ceiling-budget", type=float, default=3e6)
    ap.add_argument("--ceiling-depth", type=int, default=16)
    ap.add_argument("--ceiling-suite", type=int, default=320)
    ap.add_argument("--quick", action="store_true", help="tiny budgets, for smoke-testing the pipeline")
    a = ap.parse_args()
    if a.quick:
        for c in CFG.values():
            c.update(budget=2e4, eval_every=1e4)
    global GRAPH
    GRAPH = GRAPHS[a.graph]
    dev, out = device(a.device), Path(a.out)
    out.mkdir(exist_ok=True)
    if a.ceiling:
        return ceiling(a, dev, out)
    old = json.loads((out / "results.json").read_text()) if (out / "results.json").exists() and not a.quick else {}
    R = dict(config=dict(CFG=CFG, threshold=THRESHOLD, beam=BEAM, suite=SUITE, batch=BATCH, lr=LR, metric="qtm", graph=a.graph,
                         device=dev, source=a.source, targets=a.targets, seeds=a.seeds),
             puzzles={p: geometry(Cube(p)) for p in [a.source, *a.targets]}, runs={}, demos={})
    for k in ("puzzles", "runs", "demos"):                            # keep targets from earlier invocations
        R[k] = {**old.get(k, {}), **R[k]}
    R["config"]["targets"] = sorted(set(old.get("config", {}).get("targets", [])) | set(a.targets), key=[*CFG].index)
    R["config"]["seeds"] = sorted(set(old.get("config", {}).get("seeds", [])) | set(a.seeds))
    save = lambda: (out / "results.json").write_text(json.dumps(R))

    torch.manual_seed(0)
    src = GNN(F_in=GRAPH.F_IN, n_static=GRAPH.N_STATIC).to(dev)
    R["params"] = sum(p.numel() for p in src.parameters())
    ckpt = out / f"gnn_{a.source}.pt"
    if ckpt.exists() and not a.quick:
        src.add_puzzle(a.source)
        src.load_state_dict(torch.load(ckpt))
        R["pretrain"] = json.loads((out / "pretrain.json").read_text())
    else:
        R["pretrain"] = train(src, Cube(a.source), 0, dev, f"pretrain {a.source}")
        torch.save(src.state_dict(), ckpt)
        (out / "pretrain.json").write_text(json.dumps(R["pretrain"]))
    R["demos"][a.source] = {"pretrained": demos(src, Cube(a.source), dev)}
    save()

    for T in a.targets:
        cube, prev = Cube(T), R["runs"].get(T, {})                    # re-runs add seeds instead of replacing them
        R["runs"][T] = {r: [x for x in prev.get(r, []) if x["seed"] not in a.seeds] for r in ("scratch", "finetune")}
        R["demos"][T] = {"zero-shot": demos(src, cube, dev)}
        for seed in a.seeds:
            torch.manual_seed(seed)
            models = {"scratch": GNN(F_in=GRAPH.F_IN, n_static=GRAPH.N_STATIC).to(dev), "finetune": copy.deepcopy(src)}
            for regime, model in models.items():
                curve = train(model, cube, seed, dev, f"{regime} {T} seed {seed}")
                R["runs"][T][regime].append(dict(seed=seed, curve=curve, states_to_solve=first_hit(curve)))
                R["runs"][T][regime].sort(key=lambda x: x["seed"])
                if seed == a.seeds[0]:
                    R["demos"][T][regime] = demos(model, cube, dev)
                save()
    print(json.dumps({T: {r: [x["states_to_solve"] for x in v] for r, v in runs.items()} for T, runs in R["runs"].items()}))


if __name__ == "__main__":
    main()
